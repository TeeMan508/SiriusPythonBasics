from setuptools import setup, find_packages

setup(name='NElementChain',
      version='1.0.0',
      url='https://github.com/TeeMan508/SiriusPythonBasics',
      author='TMN',
      packages=find_packages(exclude=['tests']),
      zip_safe=False)